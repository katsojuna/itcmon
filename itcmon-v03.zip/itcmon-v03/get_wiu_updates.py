import zmq
import json

def main():
    ctx = zmq.Context()
    socket = ctx.socket(zmq.SUB)
    socket.connect("tcp://localhost:18001")
    socket.setsockopt(zmq.SUBSCRIBE, b"")  # Subscribe to all messages

    print("ZMQ Subscriber started - listening on tcp://localhost:18001")
    print("Waiting for WIU messages...\n")

    try:
        while True:
            msg_str = socket.recv_string()
            print(msg_str)
            
            try:
                data = json.loads(msg_str)
                
                # Only process WIU messages
                if data.get("type") != "WIU":
                    continue

                wiuid = data.get("WIUID")
                indicators = data.get("indicators", [])

                inew = data.get("inew", [])
                if inew:
                    print(f" Indicators changed")

                #print(f"WIU: {wiuid} | Data: {data.get('data')}")

                # === Custom Logic Example ===
                if wiuid == "780207506003":
                    for item in indicators:
                        if item.get("signal") == 2 and item.get("ind") == 3:
                            print("CLEAR CONDITION DETECTED!")
                            print(f"   WIUID: {wiuid}")
                            print(f"   Indicators: {indicators}")
                            print("-" * 60)
                            # You can add more actions here (e.g. sound alert, log, etc.)

            except json.JSONDecodeError:
                print("Failed to parse JSON:", msg_str)
            except Exception as e:
                print("Error processing message:", e)

    except KeyboardInterrupt:
        print("\nSubscriber stopped by user.")
    finally:
        socket.close()
        ctx.term()

if __name__ == "__main__":
    main()
    
